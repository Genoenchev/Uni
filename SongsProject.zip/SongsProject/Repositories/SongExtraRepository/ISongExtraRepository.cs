﻿using Models;
using System.Collections.Generic;

namespace Repositories.CarExtraRepository
{
    public interface ISongExtraRepository
    {
        void Add(SongExtra songextra);
        ICollection<SongExtra> GetSongExtras(int songId);
    }
}
