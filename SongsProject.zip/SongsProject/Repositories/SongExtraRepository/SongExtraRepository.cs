﻿using Data;
using Microsoft.EntityFrameworkCore;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Repositories.CarExtraRepository
{
    public class SongExtraRepository : ISongExtraRepository
    {
        private readonly ApplicationDbContext _appDbContext;
        public SongExtraRepository(ApplicationDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public void Add(SongExtra carextra)
        {
            _appDbContext.Entry(carextra).State = EntityState.Detached;
            _appDbContext.SongExtras.Add(carextra);
            _appDbContext.SaveChanges();
        }
        public ICollection<SongExtra> GetCarExtras(int carId) => _appDbContext.SongExtras.Include(x => x.Songs)
                                                                                      .Include(x => x.Extra)
                                                                                      .Where(x => x.SongId == carId).ToList();

        public ICollection<SongExtra> GetSongExtras(int songId)
        {
            throw new NotImplementedException();
        }
    }
}