﻿namespace Repositories.CarRepository
{
    using Models;
    using System.Collections.Generic;
    public interface ISongRepository
    {
        Songs GetSongById(int id);
        Songs GetSongByModel(string model);
        IEnumerable<Songs> GetAllSongs { get; }
        int Add(Songs song);
        void Update(Songs song);
        void Delete(int song);
    }
}
