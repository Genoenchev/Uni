﻿using Data;
using Microsoft.EntityFrameworkCore;
using Models;
using System.Collections.Generic;
using System.Linq;

namespace Repositories.CarRepository
{
    public class SongRepository : ISongRepository
    {
        private readonly ApplicationDbContext _appDbContext;
        public SongRepository(ApplicationDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public IEnumerable<Songs> GetAllSongs => _appDbContext.Songs.Include(x => x.Brand)
                                                                .Include(x => x.SongExtras).ThenInclude(x => x.Extra)
                                                                .AsNoTracking().ToList();

        // public IEnumerable<Songs> GetAllSongs => throw new System.NotImplementedException();

        public Songs GetCarById(int id) => _appDbContext.Songs.Include(x => x.Brand)
                                                                .Include(x => x.SongExtras).ThenInclude(x => x.Extra)
                                                                .AsNoTracking().SingleOrDefault(x=>x.Id == id);
        public Songs GetCarByModel(string model) => _appDbContext.Songs
                                                                    .Include(b => b.Brand)
                                                                    .Include(x => x.SongExtras)
                                                                    .ThenInclude(x => x.Extra)
                                                                    .AsNoTracking()
                                                                    .SingleOrDefault(x => x.Title == model);
        public int Add(Songs song)
        {
            _appDbContext.Songs.Add(song);
            _appDbContext.SaveChanges();
            return song.Id;
        }
        public void Update(Songs song)
        {
            Songs oldSong = _appDbContext.Songs.Single(x => x.Id == song.Id);
            oldSong.Title = song.Title;
            oldSong.YearPublished = song.YearPublished;
            oldSong.BrandId = song.BrandId;
            _appDbContext.Entry(oldSong).State = EntityState.Modified;
            //_appDbContext.Songs.Update(car);
            _appDbContext.SaveChanges();
        }
        public void Delete(int id)
        {
            Songs car = _appDbContext.Songs.Find(id);
            _appDbContext.Songs.Remove(car);
            _appDbContext.SaveChanges();
        }

        public Songs GetSongById(int id)
        {
            throw new System.NotImplementedException();
        }

        public Songs GetSongByModel(string model)
        {
            throw new System.NotImplementedException();
        }
    }
}
