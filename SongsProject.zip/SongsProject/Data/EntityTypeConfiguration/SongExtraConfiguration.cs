﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EntityTypeConfiguration
{
    public class SongExtraConfiguration : IEntityTypeConfiguration<SongExtra>
    {
        public void Configure(EntityTypeBuilder<SongExtra> builder)
        {
            builder.HasKey(tcm => new { tcm.SongId, tcm.ExtraId });

            builder.HasOne(tcm => tcm.Songs)
                .WithMany(t => t.SongExtras)
                .HasForeignKey(tcm => tcm.SongId);

            builder.HasOne(tcm => tcm.Extra)
                .WithMany(tc => tc.SongExtras)
                .HasForeignKey(tcm => tcm.ExtraId);
        }
    }
}
