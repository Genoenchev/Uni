﻿namespace Data
{
    using Microsoft.EntityFrameworkCore;
    using Models;

    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext() { }
        public ApplicationDbContext(DbContextOptions options) : base(options) { }
        public DbSet<Songs> Songs { get; set; }
        public DbSet<Brand> Brands { get; set; }
        public DbSet<Extra> Extras { get; set; }
        public DbSet<SongExtra> SongExtras { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //Server = DESKTOP-7KOSELH
            //Database = GenoMusic
            optionsBuilder.EnableSensitiveDataLogging();
            if(!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=DESKTOP-7KOSELH;Database=GenoMusic;Trusted_Connection=True");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(this.GetType().Assembly);
        }
    }
}
