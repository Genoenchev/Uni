﻿using Models;
using Repositories.BrandRepository;
using Repositories.CarRepository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarProject
{
    public partial class HomeForm : Form
    {
        private readonly ISongRepository _songRepository;
        private readonly IBrandRepository _brandRepository;

        public int SongId { get; private set; }
        public object InputYearPublished { get; private set; }

        public HomeForm()
        {
            _songRepository = (ISongRepository)StartUp.ServiceProvider.GetService(typeof(ISongRepository));
            _brandRepository = (IBrandRepository)StartUp.ServiceProvider.GetService(typeof(IBrandRepository));
            InitializeComponent();
            OnStart();
            GetData();
        }
        private void OnStart()
        {
            CarGridView.ColumnCount = 5;
            CarGridView.Columns[0].Name = "Id";
            CarGridView.Columns[1].Name = "Title";
            CarGridView.Columns[2].Name = "YearPublished";
            CarGridView.Columns[3].Name = "Brand";
            CarGridView.Columns[4].Name = "Extras";

            var brandNames = _brandRepository.GetAllBrands
                      .Select(b => b.Name).ToArray();
            this.InputBrandId.Items.AddRange(brandNames);
        }
        private void GetData()
        {
            CarGridView.Rows.Clear();
            var songsModel = _songRepository.GetAllSongs;
            foreach(Songs song in songsModel)
            {
                string[] currentRow =
                {
                    song.Id.ToString(),
                    song.Title,
                    song.YearPublished.ToString(),
                    song.Brand.Name,
                    string.Join(",",song.SongExtras.Select(x=>x.Extra.Name))
                };
                CarGridView.Rows.Add(currentRow);
            }
        }
        private void BtnCreate_Click(object sender, EventArgs e)
        {
            Brand selectBrand = _brandRepository.GetAllBrands.SingleOrDefault(b => b.Name == InputBrandId.Text);
            var song = new Songs()
            {
                Title = InputModel.Text,
                YearPublished = int.Parse(InputYearPublished.Text),
                BrandId = selectBrand.Id,
            };
            int carId = _songRepository.Add(song);
            ClearForm();
            this.Hide();
            SongExtras f2 = new SongExtras(SongId);
            f2.ShowDialog();
            GetData();

        }
        private void ClearForm()
        {
            InputId.Text = "";
            InputModel.Text = "";
            InputYear.Text = "";
            InputBrandId.Text = "";
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            var car = new Songs()
            {
                Id = int.Parse(InputId.Text),
                Title = InputModel.Text,
                YearPublished = int.Parse(InputYear.Text),
                BrandId = _brandRepository.GetAllBrands.SingleOrDefault(b => b.Name == InputBrandId.Text).Id
            };
            _songRepository.Update(car);
            ClearForm();
            GetData();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            var currentId = int.Parse(InputId.Text);
            _songRepository.Delete(currentId);
            ClearForm();
            GetData();
        }

        private void CarGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;
            InputId.Text = CarGridView.Rows[rowIndex].Cells[0].Value.ToString();
            InputModel.Text = CarGridView.Rows[rowIndex].Cells[1].Value.ToString();
            InputYear.Text = CarGridView.Rows[rowIndex].Cells[2].Value.ToString();
            InputBrandId.Text = CarGridView.Rows[rowIndex].Cells[3].Value.ToString();
        }
        private void CarGridView_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;
            int currentId  = int.Parse(CarGridView.Rows[rowIndex].Cells[0].Value.ToString());
            this.Hide();
            SongExtras f2 = new SongExtras(currentId);
            f2.ShowDialog();
        }
    }
}
