﻿using Models;
using Repositories.CarExtraRepository;
using Repositories.CarRepository;
using Repositories.ExtraRepository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CarProject
{
    public partial class SongExtras : Form
    {
        private readonly ISongExtraRepository _songExtraRepository;
        private readonly ISongRepository _songRepository;
        private readonly IExtraRepository _extraRepository;
        private readonly int _currentId;
        public SongExtras(int currentId)
        {
            _currentId = currentId;
            _songExtraRepository = (ISongExtraRepository)StartUp.ServiceProvider.GetService(typeof(ISongExtraRepository));
            _extraRepository = (IExtraRepository)StartUp.ServiceProvider.GetService(typeof(IExtraRepository));
            _songRepository = (ISongRepository)StartUp.ServiceProvider.GetService(typeof(ISongRepository));
            InitializeComponent();
            OnStart();
            GetData();
        }
        private void OnStart()
        {
            var extraNames = _extraRepository.GetAllExtras.Select(b => b.Name).ToArray();
            this.ComboExtraId.Items.AddRange(extraNames);
            this.InputCarName.Text = _songRepository.GetSongById(_currentId).Title;
            ManyToManyGrid.ColumnCount = 2;
            ManyToManyGrid.Columns[0].Name = "Name";
            ManyToManyGrid.Columns[1].Name = "Description";
        }
        private void GetData()
        {
            ManyToManyGrid.Rows.Clear();
            var songExtras = _songExtraRepository.GetSongExtras(_currentId);
            foreach (var songExtra in songExtras)
            {
                string[] currentRow =
                {
                    songExtra.Extra.Name,
                    songExtra.Extra.Description,
                };
                ManyToManyGrid.Rows.Add(currentRow);
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            Extra selectedExtra = _extraRepository.GetExtraByName(ComboExtraId.Text);
            SongExtra currentSongExtra = new SongExtra
            {
                 SongId = _currentId,
                ExtraId = selectedExtra.Id
            };
            _songExtraRepository.Add(currentSongExtra);
            GetData();
            MessageBox.Show($"Success");
            ComboExtraId.Text = "";
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomeForm f1 = new HomeForm();
            f1.ShowDialog();
        }

        private void lblCarName_Click(object sender, EventArgs e)
        {

        }
    }
}
