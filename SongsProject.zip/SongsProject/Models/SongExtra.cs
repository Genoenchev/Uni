﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Models
{
    public class SongExtra
    {
        [Required]
        public int SongId { get; set; }
        [Required]
        public int ExtraId { get; set; }
        public Songs Songs { get; set; }
        public Extra Extra { get; set; }
    }
}
